import greenfoot.*;

/**
 * This is a stick man. Make him run and jump.
 * 
 * @author 
 * @version 
 */
public class Stickman extends Actor
{
    /**
     * Make the stickman act.
     */
    public void act() 
    {        
    }    
}
