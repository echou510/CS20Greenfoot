import greenfoot.*; 

/**
 * A simple button.
 * 
 * @author Michael Kölling 
 * @version 1.0
 */
public class Button extends Actor
{
    /**
     * Act - nothing to do.
     */
    public void act() 
    {
    }    
}
